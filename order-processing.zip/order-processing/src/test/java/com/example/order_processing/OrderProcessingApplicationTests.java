package com.example.order_processing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderProcessingApplicationTests {

	@Test
	void contextLoads() {
	}

}
